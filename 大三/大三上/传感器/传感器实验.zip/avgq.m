data = xlsread("C:\Users\LCY\Desktop\传感器实验\rdo.xlsx");
x=data(1,:);
y=data(2,:); 
